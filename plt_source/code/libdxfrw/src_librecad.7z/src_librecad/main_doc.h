 
/**
 * @mainpage
 *
 * This manual documents the use of <b>libdxfrw</b>.
 * 
 * With libdxfrw you can read and write several parts of a dxf files.<p>
 * Dxf files can be written in ascii and binary form, both are supported.<p>
 * Dwg support (only read) are work in progress.<p>
 * 
 * the complete documentation and examples are pending to free time,
 * but to start see DRW_Interface, dxfRW & dwgR, classes
  */


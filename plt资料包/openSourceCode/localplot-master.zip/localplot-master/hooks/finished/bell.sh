#!/bin/bash
echo -ne '\a'

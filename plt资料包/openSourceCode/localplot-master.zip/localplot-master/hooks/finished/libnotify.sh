#!/bin/bash
notify-send 'Done plotting!' 'This is an example notification.' --icon=dialog-information

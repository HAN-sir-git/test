﻿# LED Icon Set
Site: http://led24.de/iconset

License: see below

You can do whatever you want with these icons (use on web or in desktop applications) as long as you don’t pass them off as your own and remove this readme file.
A credit statement and a link back to http://led24.de/iconset/ or http://led24.de/ would be appreciated.

Follow us on twitter http://twitter.com/gasyoun or email leds24@gmail.com
512 icons 20/05/2009


# Farm-Fresh Web Icons
Site: http://www.fatcow.com/free-icons

License: Creative Commons Attribution 3.0 (https://creativecommons.org/licenses/by/3.0/us/)

These icon sets are licensed under a Creative Commons Attribution 3.0 License.
This means you can freely use these icons for any purpose, private and commercial, including online services, templates, themes and software.
However, you should include a link to this page in your credits.
The icons may not be resold, sublicensed, rented, transferred or otherwise made available for use (including uploading the font archive to publicly available websites).
Please link to this page on fatcow.com if you would like to spread the word.


# Google Material collection
Site: https://material.io/icons/ https://www.iconfu.com/

License: Apache License 2.0 (https://www.apache.org/licenses/LICENSE-2.0.txt)


# PayPal Donate Button
Site: https://github.com/stefan-niedermann/paypal-donate-button

License: GNU Affero General Public License v3.0 (https://www.gnu.org/licenses/agpl-3.0.en.html)

PayPal is a registered trademark of PayPal, Inc. The PayPal logo is a trademark of PayPal, Inc.


# Yandex.Money Logo and Wallet Icon
Site: https://money.yandex.ru/
